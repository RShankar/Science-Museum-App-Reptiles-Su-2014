package edu.fau.group9.modscompanion;


import java.util.Locale;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class InformationActivity extends FragmentActivity {

	SectionsPagerAdapter mSectionsPagerAdapter;
	ViewPager mViewPager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_information);

		mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
		mViewPager = (ViewPager) findViewById(R.id.pager);
		mViewPager.setAdapter(mSectionsPagerAdapter);
	}
	
	protected void onResume() {
		super.onResume();
		if(getIntent().hasExtra("position")) {
			mViewPager.setCurrentItem(getIntent().getExtras().getInt("position"));
		}
	}
	
	protected void onNewIntent(Intent intent) {
		mViewPager.setCurrentItem(intent.getExtras().getInt("position"));
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public class SectionsPagerAAdapter extends FragmentStatePagerAdapter {

		public SectionsPagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			Fragment fragment = new BugSectionFragment();
			Bundle args = new Bundle();
			args.putInt(BugSectionFragment.ARG_SECTION_NUMBER, position + 1);
			fragment.setArguments(args);
			return fragment;
		}

		@Override
		public int getCount() {
			return 9;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			Locale l = Locale.getDefault();
			switch (position) {
			case 0:
				return getString(R.string.reptile_name1).toUpperCase(l);
			case 1:
				return getString(R.string.reptile_name2).toUpperCase(l);
			case 2:
				return getString(R.string.reptile_name3).toUpperCase(l);
			case 3:
				return getString(R.string.reptile_name4).toUpperCase(l);
			case 4:
				return getString(R.string.reptile_name5).toUpperCase(l);
			case 5:
				return getString(R.string.reptile_name6).toUpperCase(l);
			case 6:
				return getString(R.string.reptile_name7).toUpperCase(l);
			case 7:
				return getString(R.string.reptile_name8).toUpperCase(l);
			case 8:
				return getString(R.string.reptile_name9).toUpperCase(l);
			
			}
			return null;
		}
	}

	public static class BugSectionFragment extends Fragment {
		private View rootView;
		private ImageView reptileImageView;
		private TextView reptileTextView;
		public static final String ARG_SECTION_NUMBER = "section_number";

		public BugSectionFragment(){  }
		
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			rootView = inflater.inflate(R.layout.fragment_reptile_exhibit, container, false);
			reptileImageView = (ImageView) rootView.findViewById(R.id.reptileImageView);
		    reptileTextView = (TextView) rootView.findViewById(R.id.exhibit_info);
			switch (getArguments().getInt(ARG_SECTION_NUMBER) - 1) {
			case 0:
				reptileImageView.setImageResource(R.drawable.alligator_snapper);
				reptileTextView.setText(Integer.toString(getArguments().getInt(ARG_SECTION_NUMBER)) + " " + getString(R.string.reptile_info1));

				break;
			case 1:
				reptileImageView.setImageResource(R.drawable.american_alligator);			
				reptileTextView.setText(Integer.toString(getArguments().getInt(ARG_SECTION_NUMBER)) + " " + getString(R.string.reptile_info2));

				break;
			case 2:
				reptileImageView.setImageResource(R.drawable.bearded_dragon);
				reptileTextView.setText(Integer.toString(getArguments().getInt(ARG_SECTION_NUMBER)) + " " + getString(R.string.reptile_info3));

				break;
			case 3:
				reptileImageView.setImageResource(R.drawable.burmese_python);
				reptileTextView.setText(Integer.toString(getArguments().getInt(ARG_SECTION_NUMBER)) + " " + getString(R.string.reptile_info4));

				break;
			case 4:
				reptileImageView.setImageResource(R.drawable.corn_snake);
				reptileTextView.setText(Integer.toString(getArguments().getInt(ARG_SECTION_NUMBER)) + " " + getString(R.string.reptile_info5));

				break;
			case 5:
				reptileImageView.setImageResource(R.drawable.leopard_gecko);
				reptileTextView.setText(Integer.toString(getArguments().getInt(ARG_SECTION_NUMBER)) + " " + getString(R.string.reptile_info6));

				break;
			case 6:
				reptileImageView.setImageResource(R.drawable.loggerhead_sea_turtle);
				reptileTextView.setText(Integer.toString(getArguments().getInt(ARG_SECTION_NUMBER)) + " " + getString(R.string.reptile_info7));

				break;
			case 7:
				reptileImageView.setImageResource(R.drawable.northern_pine_snake);
				reptileTextView.setText(Integer.toString(getArguments().getInt(ARG_SECTION_NUMBER)) + " " + getString(R.string.reptile_info8));

				break;
			case 8:
				reptileImageView.setImageResource(R.drawable.painted_turtle);
				reptileTextView.setText(Integer.toString(getArguments().getInt(ARG_SECTION_NUMBER)) + " " + getString(R.string.reptile_info9));

				break;
			
			}
			
			
			return rootView;
		}
	}
}