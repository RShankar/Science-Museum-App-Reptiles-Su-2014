/** Automatically generated file. DO NOT MODIFY */
package edu.fau.group9.modscompanion;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}